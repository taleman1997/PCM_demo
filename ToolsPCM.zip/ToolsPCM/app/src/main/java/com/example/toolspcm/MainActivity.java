package com.example.toolspcm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    public static final String TAG = "PCMSample";

    private Button startAudio;
    private Button stopAudio;
    private Button playAudio;
    private Button deleteAudio;
    private Button transAudio;
    private ScrollView mScrollView;
    private TextView tv_audio_succeess;

    CountDownTimer five_sec_timer;
    PlaySound playSound = new PlaySound();
    RecorderPCM recorderPCM = new RecorderPCM();
    Player player = new Player();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    public void init(){
        mScrollView = (ScrollView) findViewById(R.id.mScrollView);
        tv_audio_succeess = (TextView) findViewById(R.id.tv_audio_succeess);
        printLog("initialization finished");
        startAudio = findViewById(R.id.onlyRecord);
        startAudio.setOnClickListener(this);
        stopAudio = findViewById(R.id.stopRecord);
        stopAudio.setOnClickListener(this);
        playAudio = findViewById(R.id.playPCM);
        playAudio.setOnClickListener(this);
        deleteAudio = findViewById(R.id.countDown);
        deleteAudio.setOnClickListener(this);
        transAudio = findViewById(R.id.transAudio);
        transAudio.setOnClickListener(this);
        deleteAudio = findViewById(R.id.deleteAudio);
        deleteAudio.setOnClickListener(this);
    }

    public void printLog(final String resultString) {
        tv_audio_succeess.post(new Runnable() {
            @Override
            public void run() {
                tv_audio_succeess.append(resultString + "\n");
                mScrollView.fullScroll(ScrollView.FOCUS_DOWN);
            }
        });
    }

    public void updateTimer(int secondLeft){
        printLog(Integer.toString(secondLeft));
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()){
            case R.id.onlyRecord:
                Thread thread_only = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        recorderPCM.StartRecord();
                        Log.e(TAG,"start");
                    }
                });
                thread_only.start();
                printLog("start only record");
                break;
            case R.id.stopRecord:
                recorderPCM.StopRecord();
                printLog("stop only record");
                break;
            case R.id.playPCM:
                if(recorderPCM.file == null){
                    printLog("no pcm to play");
                }else{
                    player.PlayRecord(recorderPCM.file);
                    printLog("start play");
                }
                break;
            case R.id.countDown:
                playSound.mOutputFreq = 16000;
                playSound.start();
                Thread thread_count = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        recorderPCM.StartRecord();
                        Log.e(TAG,"start count");
                    }
                });
                thread_count.start();
                five_sec_timer = new CountDownTimer(5000, 1000 ) {
                    @Override
                    public void onTick(long millisUntilFinished) {
                        updateTimer((int) millisUntilFinished / 1000);
                    }

                    @Override
                    public void onFinish() {
                        recorderPCM.StopRecord();
                        playSound.stop();
                        printLog("start count down");
                    }
                }.start();
                break;
            case R.id.transAudio:
                printLog("trans finished");
                break;
            case R.id.deleteAudio:
                if(recorderPCM.file != null){
                    recorderPCM.file.delete();
                    recorderPCM.file = null;
                }
                printLog("pcm is delated");
                break;
            default:
                break;
        }
    }
}