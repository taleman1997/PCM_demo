package com.example.toolspcm;

import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Environment;
import android.util.Log;

import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class RecorderPCM {

    public boolean isRecording = false;
    public static final String TAG = "PCMSample";
    public File file;

    int frequency = 44100; //44.1K sample rate
    int channelConfiguration = AudioFormat.CHANNEL_CONFIGURATION_MONO; //channel
    int audioEncoding = AudioFormat.ENCODING_PCM_16BIT;// 16 bit encode
    int bufferSize = AudioRecord.getMinBufferSize(frequency, channelConfiguration, audioEncoding);
    AudioRecord audioRecord = new AudioRecord(MediaRecorder.AudioSource.MIC, frequency, channelConfiguration, audioEncoding, bufferSize);

    public void StartRecord() {
        Log.i(TAG,"start record");
        file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/1031workfolder/tools_version.pcm");
        Log.i(TAG,"file generate");
        //如果存在，就先删除再创建
        if (file.exists())
            file.delete();
        Log.i(TAG,"del file");
        try {
            file.createNewFile();
            Log.i(TAG,"file generated");
        } catch (IOException e) {
            Log.i(TAG,"fail to generate");
            throw new IllegalStateException("fail to generate" + file.toString());
        }
        try {
            //输出流
            OutputStream os = new FileOutputStream(file);
            BufferedOutputStream bos = new BufferedOutputStream(os);
            DataOutputStream dos = new DataOutputStream(bos);

            short[] buffer = new short[bufferSize];
            audioRecord.startRecording();
            Log.i(TAG, "start record");
            isRecording = true;
            while (isRecording) {
                int bufferReadResult = audioRecord.read(buffer, 0, bufferSize);
                for (int i = 0; i < bufferReadResult; i++) {
                    dos.writeShort(buffer[i]);
                }
            }
            audioRecord.stop();
            dos.close();
        } catch (Throwable t) {
            Log.e(TAG, "record fail");
        }
    }

    public void StopRecord(){
         isRecording = false;
         //audioRecord.stop();
    }


}
